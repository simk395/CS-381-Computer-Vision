package project_2;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class Main {
	public static void main(String[] args) throws IOException {
			
			if(args.length != 10) {
				System.out.println("Invalid number of arguments.");
				System.exit(0);
			}
			
			try {
				Integer.parseInt(args[2]);
			}catch(Exception e){
				System.out.println("Invalid threshold.");
				System.exit(0);
			}
			
	//Initialize variables
			String inputFile = args[ 0 ]; 
			String maskFile = args[ 1 ];
			int thrVal = Integer.parseInt(args[2]);
			String inputImg = args[3];
			String medianOutImg = args[4];
			String medianThrImg = args[5];
			String medianPrettyPrint = args[6];
			String gaussOutImg = args[7];
			String gaussThrImg = args[8];
			String gaussPrettyPrint = args[9];
			
	//Initialize readers 
			FileReader inputReader = null ; 
			BufferedReader buffInReader = null ; 
			Scanner input = null ; 
			
			FileReader maskReader = null;
			BufferedReader buffMaskReader = null;
			Scanner mask = null;
			
	//Initialize writers
			FileWriter outputWriter = null ; 
			BufferedWriter output = null ;
	
		 
			try{
	//			Open input
				inputReader = new FileReader( inputFile ) ;
				buffInReader = new BufferedReader( inputReader) ;
				input = new Scanner( buffInReader ) ;
				
				maskReader = new FileReader( maskFile );
				buffMaskReader = new BufferedReader( maskReader );
				mask = new Scanner( buffMaskReader );
				
				outputWriter = new FileWriter(inputImg);
				output = new BufferedWriter(outputWriter);
			
	//			initialize variables
				int numRows = 0 ;
				int numCols = 0 ;
				int minVal = 0 ;
				int maxVal = 0 ;
				int maskRows = 0;
				int maskCols = 0;
				int maskMin = 0;
				int maskMax = 0;
				
				if( input.hasNextInt() ) numRows = input.nextInt() ;
				if( input.hasNextInt() ) numCols = input.nextInt() ;
				if( input.hasNextInt() ) minVal = input.nextInt() ;
				if( input.hasNextInt() ) maxVal = input.nextInt() ;
				
				if( mask.hasNextInt() ) maskRows = mask.nextInt();
				if( mask.hasNextInt() ) maskCols = mask.nextInt();
				if( mask.hasNextInt() ) maskMin = mask.nextInt();
				if( mask.hasNextInt() ) maskMax = mask.nextInt();
				
				imageProcess readObj = new imageProcess( numRows, numCols, minVal, maxVal, maskRows, maskCols, maskMin, maskMax, thrVal ) ;
				
				readObj.loadMask(mask);
				readObj.loadImage(input);
				readObj.mirrorFraming();
				readObj.imgReformat(readObj.mirrorFramedAry, minVal, maxVal, output);
				output.close();
				
				outputWriter = new FileWriter(medianOutImg);
				output = new BufferedWriter(outputWriter);
				
				readObj.computeMedian();
				readObj.imgReformat(readObj.medianAry, readObj.newMin, readObj.newMax, output);
				
				output.close();
				
				outputWriter = new FileWriter(medianThrImg);
				output = new BufferedWriter(outputWriter);
				
				readObj.threshold(readObj.medianAry, readObj.thrAry);
				readObj.imgReformat(readObj.thrAry, readObj.newMin, readObj.newMax, output);
				
				output.close();
				
				outputWriter = new FileWriter(medianPrettyPrint);
				output = new BufferedWriter(outputWriter);
				readObj.prettyPrint(readObj.thrAry, output);
				
				output.close();
				
				outputWriter = new FileWriter(gaussOutImg);
				output = new BufferedWriter(outputWriter);
				
				readObj.computeGauss();
				readObj.imgReformat(readObj.gaussAry, readObj.newMin, readObj.newMax, output);
				
				output.close();
				
				outputWriter = new FileWriter(gaussThrImg);
				output = new BufferedWriter(outputWriter);
				
				readObj.threshold(readObj.gaussAry, readObj.thrAry);
				readObj.imgReformat(readObj.thrAry, readObj.newMin, readObj.newMax, output);
				
				output.close();
				
				outputWriter = new FileWriter(gaussPrettyPrint);
				output = new BufferedWriter(outputWriter);
				
				readObj.prettyPrint(readObj.thrAry, output);
				
			}finally {
				if( input != null ) input.close() ; 
				if( mask != null ) mask.close();
				if( output != null ) output.close();
			}
		}
}
