package project_2;

import java.io.BufferedWriter;
import java.io.IOException;
import java.util.Scanner;

public class imageProcess {
	public int numRows, numCols, minVal, maxVal, maskRows, maskCols, maskMin, maskMax, newMin, newMax, thrVal;
	public int[][] mirrorFramedAry, medianAry, gaussAry, thrAry, maskAry;
	public int[] neighborAry;
	
	public imageProcess(int rows, int cols, int min, int max, int mRows, int mCols, int mMin, int mMax, int thr){
		this.numRows = rows;
		this.numCols = cols;
		this.minVal = min;
		this.maxVal = max;
		this.thrVal = thr;
		
		this.maskRows = mRows;
		this.maskCols = mCols;
		this.maskMin = mMin;
		this.maskMax = mMax;
		
		this.thrVal = thr;
		
		this.mirrorFramedAry = new int[ this.numRows + 2 ][ this.numCols + 2];
		this.medianAry = new int[ this.numRows + 2 ][ this.numCols + 2];
		this.gaussAry = new int[ this.numRows + 2 ][ this.numCols + 2];
		this.thrAry = new int[ this.numRows + 2 ][ this.numCols + 2];
		this.maskAry = new int[ this.maskRows ][ this.maskCols];
		
		this.neighborAry = new int[9];
	}
	
	public void loadMask(Scanner maskFile) {
		for(int i = 0; i < this.maskRows; i++) {
			for(int j = 0; j < this.maskCols; j++) {
				if( maskFile.hasNextInt() ) this.maskAry[i][j] = maskFile.nextInt();
			}
		}
	}
	
	public void loadImage(Scanner inputFile) {
		for(int i = 0; i < this.numRows; i++) {
			for(int j = 0; j < this.numCols; j++) {
				if( inputFile.hasNextInt() ) this.mirrorFramedAry[i+1][j+1] = inputFile.nextInt();
			}		
		}
	}
	
//	load neighbors for 3x3
	private void loadNeighbors(int i, int j) {
		int index = 0;
		
		for(int r = i - 1; r <= i + 1; r++) {
			for(int c = j - 1; c <= j + 1; c++) {
				this.neighborAry[index] = this.mirrorFramedAry[r][c];
				index++;
			}
		}

	}
	
//	simple bubble sort
	public void sort(int[] arr) {
		int l = arr.length;
		int val = 0;
		
		 for(int i = 0; i < l; i++) {
			 for(int j = i + 1; j < l; j++) {
				 if(this.neighborAry[i] > this.neighborAry[j]) {
					 val = this.neighborAry[i];
					 this.neighborAry[i] = this.neighborAry[j];
					 this.neighborAry[j] = val;
				 }
			 }
		 }
	}
	
//	mirror framing for 3x3
//  algorithm for top and bottom are the same, left and right are the same
//	algorithm for four corners are unique for each corner
	public void mirrorFraming() {
		
		//pad top and bottom
		for(int i = 0; i < this.numCols; i++) {
//			top
			this.mirrorFramedAry[0][i+1] = this.mirrorFramedAry[1][i+1];
//			bottom
			this.mirrorFramedAry[ this.numRows + 1 ][ i + 1 ] = this.mirrorFramedAry[ this.numRows ][ i + 1 ];
		}
		
//		pad left and right
		for(int i = 0; i < this.numRows; i++) {
//			left
			this.mirrorFramedAry[ i + 1 ][0] = this.mirrorFramedAry[ i + 1 ][ 1 ];
//			right
			this.mirrorFramedAry[ i + 1 ][ this.numCols + 1] = this.mirrorFramedAry[ i + 1 ][ this.numCols ];
		}
		
//		top left corner
		this.mirrorFramedAry[0][0] = this.mirrorFramedAry[1][1];
//		top right corner
		this.mirrorFramedAry[0][ this.numCols + 1 ] = this.mirrorFramedAry[1][this.numCols];
//		bottom left corner
		this.mirrorFramedAry[this.numRows + 1][0] = this.mirrorFramedAry[ this.numRows ][ 0 ];
//		bottom right corner
		this.mirrorFramedAry[ this.numRows + 1 ][ this.numCols + 1 ] = this.mirrorFramedAry[ this.numRows ][ this.numCols ];
	}
	
	public void imgReformat(int[][] inAry,int newMin,int newMax,BufferedWriter outImg) throws IOException {
		outImg.write( Integer.toString(this.numRows) + " " );
		outImg.write( Integer.toString(this.numCols) + " ");
		outImg.write( Integer.toString(newMin) + " " );
		outImg.write( Integer.toString(newMax) + "\n" );
		
		String str = Integer.toString(newMax);
		int width = str.length();
		int r = 1;
		int c = 1;
		
		while( r <= this.numRows ) {
			c = 1;
			while( c <= this.numCols ) {
				outImg.write( Integer.toString(inAry[r][c]) + " ");
				str = Integer.toString(inAry[r][c]);
				int ww = str.length();
				
				while( ww < width) {
					outImg.write(" ");
					ww++;
				}
				c++;
			}
			outImg.write("\n");
			r++;
		}
	}
	
	public void computeMedian() {
		this.newMin = 9999;
		this.newMax = 0;
		int i = 1;
		int j = 1;
		
		while( i <= this.numRows ) {
			j = 1;	
			while( j <= this.numCols ) {
				this.loadNeighbors(i, j);
				this.sort(this.neighborAry);
				this.medianAry[i][j] = this.neighborAry[4];
				if( this.newMin > this.medianAry[i][j] ) this.newMin = this.medianAry[i][j];
				if( this.newMax < medianAry[i][j] ) this.newMax = this.medianAry[i][j];
				j++;
			}
			i++;
		}

	}
	
	public void computeGauss() {
		this.newMin = 9999;
		this.newMax = 0;
		int i = 1;
		int j = 1;
		while( i <= this.numRows ) {
			j = 1;
			while( j <= this.numCols ) {
				this.gaussAry[i][j] = this.convolution(i, j, this.mirrorFramedAry, this.maskAry);
				if(this.newMin > this.gaussAry[i][j]) this.newMin = this.gaussAry[i][j];
				if(this.newMax < this.gaussAry[i][j]) this.newMax = this.gaussAry[i][j];
				j++;
			}
			i++;
		}
		
		
		
	}
	
	private int convolution(int i,int j, int[][] ary, int[][] mask) {
		int totalWeight = 0;
		int product = 0;
		int l = 0;
		int k = 0;
		
		for(int r = i - 1; r <= i + 1; r++) {
			k = 0;
			for(int c = j - 1; c <= j + 1; c++) {
				product += ( mask[l][k] * ary[r][c] );
				totalWeight += mask[l][k];
				k++;
			}
			l++;
		}
		
		int weightAverage = product/totalWeight;
		return weightAverage;
	}
	
	public void threshold(int[][] ary1, int[][] ary2) {
		this.newMin = 0;
		this.newMax = 1;
		int i = 1;
		int j = 1;
		
		while( i < this.numRows + 2 ) {
			j = 1;
			while( j < this.numCols + 2) {
				if(ary1[i][j] >= this.thrVal) ary2[i][j] = 1;
				else ary2[i][j] = 0;
				j++;
			}
			i++;
		}
	}
	
	public void prettyPrint(int[][] inAry, BufferedWriter outFile) throws IOException {
		for(int i = 0; i < this.numRows; i++) {
			for( int j = 0; j < this.numCols; j++) {
				if(inAry[i][j] > 0) outFile.write( Integer.toString(inAry[i][j]) + " ");
				else outFile.write(". ");
			}
			outFile.write("\n");
		}
	}
	
}
