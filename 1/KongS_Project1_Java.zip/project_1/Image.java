package project_1;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class Image {
	public int numRows=0 , numCols=0 , minVal=0 , maxVal=0 ;
	public int[] histAry;
	
	public Image( int rows , int cols , int min , int max ){
		this.numRows = rows ;
		this.numCols = cols ;
		this.minVal = min ;
		this.maxVal = max ;
		this.histAry = new int[ this.maxVal + 1 ]; //initialized to zero by default
	}
	
	public void computeHist(int pixel){
		this.histAry[pixel]++;
	}
	
	public void printHist(String output_name) throws IOException  {
		FileWriter outputWriter = null ; 
		BufferedWriter output = null ;
		try {
			outputWriter = new FileWriter( output_name ) ;
			output = new BufferedWriter( outputWriter ) ;
			output.write( Integer.toString( this.numRows ) + " " ) ;
			output.write( Integer.toString( this.numCols ) + " " ) ;
			output.write( Integer.toString( this.minVal ) + " " ) ;
			output.write( Integer.toString( this.maxVal ) + "\n" ) ;
			for( int i = 0 ; i< this.histAry.length ; ++i ){
				output.write( Integer.toString(i) + " " + Integer.toString(this.histAry[i]) + "\n" );
			}
			
		}finally {
			if( output != null ) output.close() ; 
		}
	
	}
	
	public void dispHist(String output_name) throws IOException {
		FileWriter outputWriter = null ; 
		BufferedWriter output = null ;
		
		try {
			outputWriter = new FileWriter( output_name ) ;
			output = new BufferedWriter( outputWriter ) ;
			output.write( Integer.toString( this.numRows ) + " " ) ;
			output.write( Integer.toString( this.numCols ) + " " ) ;
			output.write( Integer.toString( this.minVal ) + " " ) ;
			output.write( Integer.toString( this.maxVal ) + "\n" ) ;
			for( int i = 0 ; i< this.histAry.length ; ++i ){
				output.write( Integer.toString(i) + " (" + Integer.toString(this.histAry[i]) + "):");
				for(int j = 0; j < this.histAry[i]; j++) {
					output.write("+");
				}
				output.write("\n");
			}
			
		}finally {
			if( output != null ) output.close();
		}
	}
	
	public void threshold(String input_name, String output_1, String output_2, String threshold) throws IOException {
		this.minVal = 0;
		this.maxVal = 1;
		
		FileWriter outputWriter = null ; 
		FileWriter outputWriter_2 = null ; 
		BufferedWriter bufferWriter = null ;
		BufferedWriter bufferWriter_2 = null;
		FileReader inputReader = null ; 
		BufferedReader buffInReader = null ; 
		Scanner input = null ; 
		
		try {
			outputWriter = new FileWriter( output_1, true ) ;
			bufferWriter = new BufferedWriter( outputWriter ) ;
			
			outputWriter_2 = new FileWriter( output_2, true ) ;
			bufferWriter_2 = new BufferedWriter( outputWriter_2);
			
//			create output headers
			bufferWriter.write( Integer.toString( this.numRows ) + " " ) ;
			bufferWriter.write( Integer.toString( this.numCols ) + " " ) ;
			bufferWriter.write( Integer.toString(this.minVal) + " " ) ;
			bufferWriter.write( Integer.toString(this.maxVal) + "\n" ) ;
			bufferWriter_2.write( Integer.toString( this.numRows ) + " " ) ;
			bufferWriter_2.write( Integer.toString( this.numCols ) + " " ) ;
			bufferWriter_2.write( Integer.toString(this.minVal) + " " ) ;
			bufferWriter_2.write( Integer.toString(this.maxVal) + "\n" ) ;
			
//		read input
			inputReader = new FileReader( input_name ) ;
			buffInReader = new BufferedReader( inputReader) ;
			input = new Scanner( buffInReader ) ;
			
//		skip header
			for(int i = 0; i < 4; i++) {
				if( input.hasNextInt() ) input.nextInt() ;
			}
			
		
			
//		read pixels and write output
			for( int i = 0 ; i < this.numRows ; ++i ) {
				for( int j = 0 ; j < this.numCols ; ++j ) {
					if( input.hasNextInt() ) {
						if( input.nextInt() >= Integer.parseInt(threshold) ) {
							bufferWriter.write("1 ");
							bufferWriter_2.write("1 ");
						}else {
							bufferWriter.write("0 ");
							bufferWriter_2.write(". ");
						}
					}
					else{ System.out.println( "Corrupted input data" ) ; System.exit(0); }
				}
				bufferWriter.write("\n");
				bufferWriter_2.write("\n");
			}
			
			
		}finally {
			if( input != null ) input.close();
			if( bufferWriter != null ) bufferWriter.close();
			if( bufferWriter_2 != null ) bufferWriter_2.close();
			
		}
		
	}
}
