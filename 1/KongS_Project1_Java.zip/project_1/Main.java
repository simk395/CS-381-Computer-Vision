package project_1;
import java.io.*;
import java.util.Scanner;
public class Main{ 
	public static void main(String[] args) throws IOException {
		
		if(args.length != 6) {
			System.out.println("Invalid number of arguments.");
			System.exit(0);
		}
		
		try {
			Integer.parseInt(args[1]);
		}catch(Exception e){
			System.out.println("Invalid threshold.");
			System.exit(0);
		}
		
//Initialize variables
		String inputName = args[ 0 ]; 
		String threshold = args[ 1 ];
		String output_1 = args[ 2 ];
		String output_2 = args[ 3 ];
		String output_3 = args[ 4 ];
		String output_4 = args[ 5 ];
		FileReader inputReader = null ; 
		BufferedReader buffInReader = null ; 
		Scanner input = null ; 
		FileWriter outputWriter = null ; 
		BufferedWriter output = null ;
		FileWriter outputWriter_2 = null;
		BufferedWriter output2 = null;
	 
		try{
//			Open input
			inputReader = new FileReader( inputName ) ;
			buffInReader = new BufferedReader( inputReader) ;
			input = new Scanner( buffInReader ) ;
			
//			Read input
			int numRows = 0 ;
			if( input.hasNextInt() ) numRows = input.nextInt() ;
			int numCols = 0 ;
			if( input.hasNextInt() ) numCols = input.nextInt() ;
			int minVal = 0 ;
			if( input.hasNextInt() ) minVal = input.nextInt() ;
			int maxVal = 0 ;
			if( input.hasNextInt() ) maxVal = input.nextInt() ;
			Image readObj = new Image( numRows, numCols, minVal, maxVal ) ;
			
			for( int i = 0 ; i < readObj.numRows ; ++i ) {
				for( int j = 0 ; j < readObj.numCols ; ++j ) {
					if( input.hasNextInt() ) {
						readObj.computeHist(input.nextInt());
					}
					else{ System.out.println( "Corrupted input data" ) ; System.exit(0); }
				}
			}
			
			readObj.printHist(output_1);
			readObj.dispHist(output_2);
			
//			Close input
			input.close();
			
//			Reopen input
			inputReader = new FileReader( inputName ) ;
			buffInReader = new BufferedReader( inputReader) ;
			input = new Scanner( buffInReader ) ;
			
			
//			Output 3
			outputWriter = new FileWriter( output_3 ) ;
			output = new BufferedWriter( outputWriter ) ;
			output.write("The threshold value used is " + threshold + "\n");
			
//			Output 4
			outputWriter_2 = new FileWriter(output_4);
			output2 = new BufferedWriter( outputWriter_2 );
			output2.write("The threshold value used is " + threshold + "\n");
			
			output.flush();
			output2.flush();
			readObj.threshold(inputName, output_3, output_4, threshold );	
			
		}finally {
			if( input != null ) input.close() ; 
			if( output != null) output.close();
			if( output2 != null) output2.close();
		}
	}
}
