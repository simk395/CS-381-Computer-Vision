package Project_7;

import java.io.BufferedWriter;
import java.io.IOException;
import java.util.Scanner;

public class HoughTransform {
	public int numRows, numCols, minVal, maxVal, houghMinVal, houghMaxVal, houghDist, houghAngle, angleInDegree, offset;
	public int[][] imgAry, houghAry;
	public double angleInRadians;
	
	public HoughTransform(int rows, int cols, int min, int max) {
		this.numRows = rows;
		this.numCols = cols;
		this.minVal = min;
		this.maxVal = max;
		this.houghMinVal = 999;
		this.houghMaxVal = 0;
		this.houghAngle = 180;
		this.offset = (int) Math.ceil( Math.sqrt( Math.pow(this.numRows, 2) + Math.pow(this.numCols, 2) ));
		this.houghDist = 2 * this.offset;
		this.imgAry = new int [this.numRows][this.numCols];
		this.houghAry = new int [this.houghDist][this.houghAngle];
	}
	
	public void loadImage(Scanner input) {
		for(int i = 0; i < this.numRows; i++) {
			for(int j = 0; j < this.numCols; j++) {
				if( input.hasNextInt() ) this.imgAry[i][j] = input.nextInt();
			}		
		}
	}
	
	public void buildHoughSpace(){
		for(int x = 0; x < this.numRows; x++) {
			for(int y = 0; y < this.numCols; y++) {
				int p = this.imgAry[x][y];
				if(p > 0) {
					computeSinusoid(x, y);
				}
			}
		}
	}
	
	public double polarDistance(int x, int y, double radians){
		return ( x * Math.cos(radians) ) + ( y * Math.sin(radians) ) + this.offset;
	}
	
	public void prettyPrint(int rows, int cols, int[][] ary, BufferedWriter output) throws IOException {
		for(int i = 0; i < rows; i++) {
			for( int j = 0; j < cols; j++) {
				if(ary[i][j] > 0) output.write(Integer.toString(ary[i][j]) + " ");
				else output.write(". ");
			}
			output.write("\n");
		}
	}
	
	public void determineMinMax(int[][] arr) {
		for(int i = 0; i < this.houghDist; i++) {
			for(int j = 0; j < this.houghAngle; j++) {
				if(arr[i][j] > this.houghMaxVal) this.houghMaxVal = arr[i][j];
				else if(arr[i][j] < this.houghMinVal) this.houghMinVal = arr[i][j];
			}
		}
	}
	
	public void printHeader(int rows, int cols, int min, int max, BufferedWriter output) throws IOException {
		String r = Integer.toString(rows);
		String c = Integer.toString(cols);
		String l = Integer.toString(min);
		String h = Integer.toString(max);
		output.write(r + " " + c + " " + l + " " + h + "\n");
	}
	
	public void aryToFile(int[][] arr, BufferedWriter output) throws IOException {
		for(int i = 0; i < this.houghDist; i++) {
			for(int j = 0; j < this.houghAngle; j++) {
				output.write( Integer.toString(arr[i][j]) + " ");
			}
			output.write("\n");
		}
	}
	
	public void computeSinusoid(int x, int y) {
		this.angleInDegree = 0;
		
		while( this.angleInDegree <= 179) {
			this.angleInRadians = (this.angleInDegree / 180.00) * Math.PI;
			double dist = polarDistance(x, y, this.angleInRadians);
			int distInt = (int) dist;
			this.houghAry[distInt][angleInDegree]++;
			this.angleInDegree++;
		}
	}
}
