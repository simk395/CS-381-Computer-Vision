package Project_7;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class Main {
	public static void main(String[] args) throws IOException {
			if(args.length != 3) {
				System.out.println("Invalid number of arguments.");
				System.exit(0);
			}
	//	Initialize variables
			String inputFile = args[ 0 ]; 
			String prettyPrintFile = args[ 1 ];
			String houghFile = args[ 2 ];
					
	//	Open input
			FileReader inputReader = new FileReader( inputFile ) ;
			BufferedReader buffInReader = new BufferedReader( inputReader) ;
			Scanner input = new Scanner( buffInReader ) ;
	
			FileWriter prettyPrintWriter = new FileWriter(prettyPrintFile);
			BufferedWriter prettyPrintOutput = new BufferedWriter(prettyPrintWriter);
			
			FileWriter houghWriter = new FileWriter(houghFile);
			BufferedWriter houghOutput = new BufferedWriter(houghWriter);
			
			try{
	//	initialize variables
				int numRows = 0 ;
				int numCols = 0 ;
				int minVal = 0 ;
				int maxVal = 0 ;
				
				if( input.hasNextInt() ) numRows = input.nextInt() ;
				if( input.hasNextInt() ) numCols = input.nextInt() ;
				if( input.hasNextInt() ) minVal = input.nextInt() ;
				if( input.hasNextInt() ) maxVal = input.nextInt() ;
				
				HoughTransform houghObj = new HoughTransform( numRows, numCols, minVal, maxVal ) ;
				houghObj.loadImage(input);
				houghObj.buildHoughSpace();
				houghObj.prettyPrint(houghObj.houghDist, houghObj.houghAngle, houghObj.houghAry, prettyPrintOutput);
				houghObj.determineMinMax(houghObj.houghAry);
				houghObj.printHeader(houghObj.houghDist, houghObj.houghAngle, houghObj.houghMinVal, houghObj.houghMaxVal, houghOutput);
				houghObj.aryToFile(houghObj.houghAry, houghOutput);
							
			}finally {
				if( input != null ) input.close() ; 
				if( prettyPrintOutput != null ) prettyPrintOutput.close();
				if( houghOutput != null ) houghOutput.close();
			
			}
		}
}