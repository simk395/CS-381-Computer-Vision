package Project_5;

public class Property {
	public int label, numPixels, minR, minC, maxR, maxC;
	
	public Property() {
		this.label = 0;
		this.numPixels = 0;
		this.minR = 99999;
		this.minC = 99999;
		this.maxR = 0;
		this.maxC = 0;
	}
	
	public void setLabel(int val) {
		this.label = val;
	}
	
	public void incPixels() {
		this.numPixels++;
	}
	
	public void setMinR(int val) {
		this.minR = val;
	}
	
	public void setMinC(int val) {
		this.minC = val;
	}
	
	public void setMaxC(int val) {
		this.maxC = val;
	}
	
	public void setMaxR(int val) {
		this.maxR = val;
	}
}
