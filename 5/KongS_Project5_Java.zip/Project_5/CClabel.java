package Project_5;

import java.io.BufferedWriter;
import java.io.IOException;
import java.util.Scanner;
import java.util.HashSet;

public class CClabel {
	public int numRows, numCols, minVal, maxVal, newMin, newMax, newLabel, trueNumCC;
	public int[][] zeroFramedAry;
	public int[] nonZeroNeighborAry, eqAry;
	public Property[] propertyFiles;
	
	public CClabel(int rows, int cols, int min, int max){
		this.numRows = rows;
		this.numCols = cols;
		this.minVal = min;
		this.maxVal = max;
		this.newMin = 99999;
		this.newMax = 0;
		this.newLabel = 0;
		this.nonZeroNeighborAry = new int[5];
		
		int eqSize = (this.numRows * this.numCols)/4;
		this.eqAry = new int[ eqSize ];
		for(int i = 0; i < eqSize; i++) {
			eqAry[i] = i;
		}
		
		this.zeroFramedAry = new int[this.numRows + 2][this.numCols + 2];
		zero2D(this.numRows + 2, this.numCols + 2, this.zeroFramedAry);		
	}
	
	public void zero2D(int r, int c, int[][]ary) {
		for(int i = 0; i < r; i++) {
			for(int j = 0; j < c; j++) {
				ary[i][j] = 0;
			}
		}
	}
	
	public void minus1D(int size, int[] ary) {
		for(int i = 0; i < size; i++) {
			ary[i] = -1;
		}
	}
	
	public void loadImage(int[][] ary, Scanner input) {
		for(int i = 1; i < this.numRows + 1; ++i) {
			for(int j = 1; j < this.numCols + 1; ++j) {
				if( input.hasNextInt() )
				ary[i][j] = input.nextInt();
			}
		}
	}
	
	public void connect4Pass1() {
		for(int i = 1; i < this.numRows + 1; i++) {
			for(int j = 1; j < this.numCols + 1; j++) {
				if( this.zeroFramedAry[i][j] > 0 ) {	
					int a = this.zeroFramedAry[i-1][j];
					int b = this.zeroFramedAry[i][j-1];
//					Case 1:
					if( a == 0 && b == 0 ) {
						this.newLabel++;
						this.zeroFramedAry[i][j] = this.newLabel;	
					}
//					Case 2:
					else if( a != 0 && b != 0 ) {
						int min = Math.min(a, b);
						int max = Math.max(a, b);
						this.zeroFramedAry[i][j] = min;
						this.eqAry[ max ] = min; 
					}	
//					Case 3:
					else if( a != 0 || b != 0 ) {
						if( a == 0 ) this.zeroFramedAry[i][j] = b;
						else  this.zeroFramedAry[i][j] = a;
					}
				}
			}
		}
	}
	
	public void connect4Pass2() {
		for(int i = this.numRows + 1; i > 0; i--) {
			for(int j = this.numCols + 1; j > 0; j--) {
				
				int p = this.zeroFramedAry[i][j];
				if(p > 0) {
					int c = this.zeroFramedAry[i][j+1];
					int d = this.zeroFramedAry[i+1][j];
					
//					case 1:
					if( c == 0 && d == 0);
//					case 2:
					else if( c == d && d == p);
//					case 3:
					else if(((p != c && p != d) ||
							 (c != d && c != p) ||
							 (d != p && d != c)) &&
							 (c != 0 && d != 0)) {
						int min = Math.min(Math.min(c, d), p);
						if( p > min) {
							this.eqAry[p] = min;
							this.zeroFramedAry[i][j] = min;
						}
					}
//					step 3
					else {
						this.zeroFramedAry[i][j] = this.eqAry[p];
					}
				}
				
			}
		}
	}
	
	public void connect8Pass1() {
		for(int i = 1; i < this.numRows + 1; i++) {
			for(int j = 1; j < this.numCols + 1; j++) {
				if( this.zeroFramedAry[i][j] > 0 ) {	
					
					int a = this.zeroFramedAry[i-1][j-1];
					int b = this.zeroFramedAry[i-1][j];
					int c = this.zeroFramedAry[i-1][j+1];
					int d = this.zeroFramedAry[i][j-1];
					
//					Case 1:
					if( a == b && b == c && c == d && d == 0) {
						this.newLabel++;
						this.zeroFramedAry[i][j] = this.newLabel;	
					}
					
					else if( a != 0 || b != 0 || c != 0 || d != 0 ) {
						
						int[] arr = {a,b,c,d};
						HashSet<Integer> labels = new HashSet<Integer>();
						
						for(int k = 0; k < 4; k++) 
							labels.add(arr[k]);
						
//						ignore zeroes
						labels.remove(0);
						if(labels.size() == 1) {
//							case 2:
							for(int n : labels)
								this.zeroFramedAry[i][j] = n;
						}else {
//							case 3:
							int min = 999999;
							int max = 0;
							for(int n : labels) {
								if(n < min) min = n;
								if(n > max) max = n;
							}
							this.zeroFramedAry[i][j] = min;
							this.eqAry[ max ] = min; 
						}
					}
				}
			}
		}
	}
	
	public void connect8Pass2() {
		for(int i = this.numRows + 1; i > 0; i--) {
			for(int j = this.numCols + 1; j > 0; j--) {
				int p = this.zeroFramedAry[i][j];
				if(p > 0) {
					int e = this.zeroFramedAry[i][j+1];
					int f = this.zeroFramedAry[i+1][j-1];
					int g = this.zeroFramedAry[i+1][j];
					int h = this.zeroFramedAry[i+1][j+1];
					
//					case 1:
					if( e == f && f == g && g == h && h == 0);
//					case 2:
					else if( e != 0 || f != 0 || g != 0 || h != 0 ) {
						int[] arr = {e,f,g,h,p};
						HashSet<Integer> labels = new HashSet<Integer>();
						for(int k = 0; k < arr.length; k++) 
							labels.add(arr[k]);
//						ignore zeroes
						labels.remove(0);
						
//						case 2 bypassed by > 1
						if(labels.size() > 1) {
//							case 3:
							int min = 999999;
							int max = 0;
							for(int n : labels) {
								if(n < min) min = n;
								if(n > max) max = n;
							}
							this.zeroFramedAry[i][j] = min;
							this.eqAry[ max ] = min; 
						}
					}
					else {
						this.zeroFramedAry[i][j] = this.eqAry[p];
					}
				}
			}
		}
	}
	
	public void connectPass3(int numCC) {
		
		this.propertyFiles = new Property[numCC + 1];
		for(int i = 0; i <= numCC; i++) {
			propertyFiles[i] = new Property();
		}
		
		for(int i = 1; i < this.numRows + 2; i++) {
			for(int j = 1; j < this.numCols + 2; j++) {
				int p = this.zeroFramedAry[i][j];
				if( p > 0) {
					this.zeroFramedAry[i][j] = this.eqAry[p];
					p = this.zeroFramedAry[i][j];
					if (p < this.newMin) this.newMin = p;
					if (p > this.newMax) this.newMax = p;
					propertyFiles[p].setLabel(p);
					propertyFiles[p].incPixels();
					
					if(propertyFiles[p].minR > i) propertyFiles[p].setMinR(i);
					if(propertyFiles[p].minC > j) propertyFiles[p].setMinC(j);
					if(propertyFiles[p].maxR < i) propertyFiles[p].setMaxR(i);
					if(propertyFiles[p].maxC < j) propertyFiles[p].setMaxC(j);
				}
			}
		}
	}
	
	public int manageEqAry() {
		int readLabel = 0;
		int index = 1;
		
		while( index <= this.newLabel) {
			if( index != this.eqAry[index] ) this.eqAry[index] = this.eqAry[ this.eqAry[index] ];

			else {
				readLabel++;
				this.eqAry[index] = readLabel;
			}
			index++;
		}
		this.trueNumCC = readLabel;
		return this.trueNumCC;
	}
	
	
	
	public void printEQAry(int label, BufferedWriter output) throws IOException {
		for(int i = 0; i < label; i++) {
			output.write(i + " ");
			output.write(this.eqAry[i] + "\n");
		}
		output.write("\n\n");
	}
	
	public void printImg(int[][]ary, BufferedWriter output) throws IOException{
		output.write( this.numRows + " ");
		output.write( this.numCols + " ");
		output.write( this.minVal + " " );
		output.write( this.trueNumCC + "\n" );
		
		for(int i = 1; i < this.numRows + 1; ++i) {
			for(int j = 1; j < this.numCols + 1; ++j) {
				int numDigits = getNumDigits(this.newLabel);
				int modSize = (int) Math.pow(10, numDigits);
				if( (ary[i][j] != 0) && (modSize % ary[i][j] < modSize) ) {
					int modDigits = getNumDigits(modSize);
					numDigits = getNumDigits(ary[i][j]);
					for(int k = 0; k < modDigits - numDigits; k++) {
						output.write(" ");
					}
				}else if( ary[i][j] == 0) {
					int modDigits = getNumDigits(modSize);
					for(int k = 0; k < modDigits - 1; k++) {
						output.write(" ");
					}
				}
				output.write( ary[i][j] + " " );
				
			}
			output.write("\n");
		}
	}
	
	private int getNumDigits(int n) {
		return String.valueOf(n).length();
	}
	
	public void printCCproperty(Property[] propertyFile, BufferedWriter output) throws IOException {
		output.write( this.numRows + " ");
		output.write( this.numCols + " ");
		output.write( this.newMin + " " );
		output.write( this.newMax + "\n" );
		output.write( this.trueNumCC + "\n" );
		
		for(int i = 1; i <= this.trueNumCC; i++) {
			Property cc = propertyFile[i];
			output.write(cc.label + "\n");
			output.write(cc.numPixels + "\n");
			output.write(cc.minR + " " + cc.minC + "\n");
			output.write(cc.maxR + " " + cc.maxC + "\n");			
		}
	}
	
	public void imageReformat(int[][] ary, BufferedWriter output) throws IOException {
		for(int i = 1; i < this.numRows + 1; ++i) {
			for(int j = 1; j < this.numCols + 1; ++j) {
				int numDigits = getNumDigits(this.newLabel);
				int modSize = (int) Math.pow(10, numDigits);
				if( (ary[i][j] != 0) && (modSize % ary[i][j] < modSize) ) {
					int modDigits = getNumDigits(modSize);
					numDigits = getNumDigits(ary[i][j]);
					for(int k = 0; k < modDigits - numDigits; k++) {
						output.write(" ");
					}
				}
				if( ary[i][j] == 0) {
					int modDigits = getNumDigits(modSize);
					for(int k = 0; k < modDigits - 1; k++) {
						output.write(" ");
					}
					output.write(". ");
				}else {
					output.write( ary[i][j] + " ");
				}
			}
			output.write("\n");
		}
	}
	
	public void drawBoxes(int[][] ary, Property[] propertyFile) {
	
		for(int i = 1; i <= this.trueNumCC; i++) {
			Property cc = propertyFile[i];
			int minRow = cc.minR;
			int minCol = cc.minC;
			int maxRow = cc.maxR;
			int maxCol = cc.maxC;
			int label = cc.label;
			
//			left to right on top and bottom
			while(minCol <= maxCol) {
				ary[minRow][minCol] = label;
				ary[maxRow][minCol] = label;
				minCol++;
			}
			
			minCol = cc.minC;
//			top to bottom on left and right
			while(minRow <= maxRow) {
				ary[minRow][minCol] = label;
				ary[minRow][maxCol] = label;
				minRow++;
			}
		}
	}
}
	
	
