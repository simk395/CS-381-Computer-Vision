package Project_5;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class Main {
	public static void main(String[] args) throws IOException {
			if(args.length != 4) {
				System.out.println("Invalid number of arguments.");
				System.exit(0);
			}
	//Initialize variables
			String inputFile = args[ 0 ]; 
			String prettyPrintFile = args[ 1 ];
			String labelFile = args[ 2 ];
			String propertyFile = args[ 3 ];
			
			
	//Initialize readers 
			FileReader inputReader = null ; 
			BufferedReader buffInReader = null ; 
			Scanner input = null ;
			Scanner userInput = null;
			
	//Initialize writers
			FileWriter outputWriter1 = null ; 
			BufferedWriter output1 = null ;
			
			FileWriter outputWriter2 = null ; 
			BufferedWriter output2 = null ;

			FileWriter outputWriter3 = null ; 
			BufferedWriter output3 = null ;
	
		 
			try{
	//			Open input
				inputReader = new FileReader( inputFile ) ;
				buffInReader = new BufferedReader( inputReader) ;
				input = new Scanner( buffInReader ) ;
				
				userInput = new Scanner(System.in);
		
				outputWriter1 = new FileWriter(prettyPrintFile);
				output1 = new BufferedWriter(outputWriter1);
				
				outputWriter2 = new FileWriter(labelFile);
				output2 = new BufferedWriter(outputWriter2);
				
				outputWriter3 = new FileWriter(propertyFile);
				output3 = new BufferedWriter(outputWriter3);
			
	//			initialize variables
				int numRows = 0 ;
				int numCols = 0 ;
				int minVal = 0 ;
				int maxVal = 0 ;
				
				if( input.hasNextInt() ) numRows = input.nextInt() ;
				if( input.hasNextInt() ) numCols = input.nextInt() ;
				if( input.hasNextInt() ) minVal = input.nextInt() ;
				if( input.hasNextInt() ) maxVal = input.nextInt() ;
				
				CClabel ccObj = new CClabel( numRows, numCols, minVal, maxVal ) ;
				
				ccObj.loadImage(ccObj.zeroFramedAry, input);
				output1.write("Original Image: \n");
				ccObj.imageReformat(ccObj.zeroFramedAry, output1);
				
				
//				user input
				int connectness = 0;
				boolean flag = true;
				while( flag ) {
					try {
						System.out.println("Please enter 4 or 8 for connectness:");
						String val = userInput.next();
						connectness = Integer.parseInt(val);
					}catch(Exception e){
						System.out.println("Invalid input. Try again.");
					}finally {
						if(connectness == 4 || connectness == 8) flag = false;
					}
				}
				userInput.close();
				
				if( connectness == 4 ) {
					ccObj.connect4Pass1();
					output1.write("Zero Framed Array after pass 1 with padding (4 connectness): \n");
					ccObj.imageReformat( ccObj.zeroFramedAry, output1);
					output1.write("Equivalence Table after pass 1 (4 connectness): \n");
					ccObj.printEQAry(ccObj.newLabel, output1); 
					output1.write("Zero Framed Array after pass 2 with padding (4 connectness): \n");
					ccObj.connect4Pass2();
					ccObj.imageReformat( ccObj.zeroFramedAry, output1);
					output1.write("Equivalence Table after pass 2 (4 connectness): \n");
					ccObj.printEQAry(ccObj.newLabel, output1); 
				}
				
				else if( connectness == 8 ) {
					ccObj.connect8Pass1();
					output1.write("Zero Framed Array after pass 1 with padding (8 connectness): \n");
					ccObj.imageReformat( ccObj.zeroFramedAry, output1);
					output1.write("Equivalence Table after pass 1 (8 connectness): \n");
					ccObj.printEQAry(ccObj.newLabel, output1); 
					output1.write("Zero Framed Array after pass 2 with padding (8 connectness): \n");
					ccObj.connect8Pass2();
					ccObj.imageReformat( ccObj.zeroFramedAry, output1);
					output1.write("Equivalence Table after pass 2 (8 connectness): \n");
					ccObj.printEQAry(ccObj.newLabel, output1); 
				}
				
				int trueNumCC = ccObj.manageEqAry();
				output1.write("Equivalence Table after Management: \n");
				ccObj.printEQAry(ccObj.newLabel, output1); 
				ccObj.connectPass3(trueNumCC);
				output1.write("Zero Framed Array after pass 3: \n");
				ccObj.imageReformat( ccObj.zeroFramedAry, output1);
				output1.write("Equivalence Table after pass 3: \n");
				ccObj.printEQAry(ccObj.newLabel, output1);
				ccObj.printImg(ccObj.zeroFramedAry, output2);
				ccObj.printCCproperty(ccObj.propertyFiles, output3);
				ccObj.drawBoxes(ccObj.zeroFramedAry, ccObj.propertyFiles);
				output1.write("Zero Framed Array after Drawing Boxes: \n");
				ccObj.imageReformat( ccObj.zeroFramedAry, output1);
				
			}finally {
				if( input != null ) input.close() ; 
				if( output1 != null ) output1.close();
				if( output2 != null ) output2.close();
				if( output3 != null ) output3.close();
			}
		}
}
